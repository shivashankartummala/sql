Prerequisites
=============
1) Gradle - https://gradle.org/install/
2) (optional) IDE with gradle support, for example:
   https://netbeans.apache.org/download/index.html
   Tools -> Plugins -> Available Plugins -> Search -> Gradle Support

db-provision-gradle-plugin
==========================
This gradle plugin adds gradle tasks that set up an oracle database using a declarative DSL (see the example plugin usage). There are basic JUnit tests for the plugin and each task

The plugin is built from the project root directory (gradle build) and the resulting jar file is in build/libs.

Example plugin usage
====================
An example gradle build that uses the plugin can be found in the example directory. It references the jar file from the build (/build/libs/db-provision-gradle-plugin.jar)

To run a simulation (no oracle database present):
 1) From example directory run the provisioning "gradle -m provision"

To run the example (oracle database available):
 1) Modify the dba { ... } block in example/build.gradle to connect to a dba user on an oracle database
 2) From example directory list the available tasks "gradle tasks"
 3) From example directory run the provisioning "gradle provision"



Task Description
================
1) Add the capability to provision database users, to include the following features:
  a) Specifying username and password
  b) Specifying tablespace
  c) Users can be assigned system privileges
  d) Users can be assigned database roles (including those provisioned by the plugin)
  e) Some of the database roles assigned to a user may be specified as non-default roles

2) Modify the example gradle build to demonstrate all of these features
