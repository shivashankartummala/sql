package oracle.oal.tools.db.gradle.extension

import org.gradle.api.Project
import org.gradle.api.Task

// Container for the database admin information
class DbaExtension {

    // Pointer to the gradle project, used to process the tasks added for a project
    Project project

    // System Properties
    String dbaUser = "SYSTEM"
    String dbaPass = ""
    String dbUrl = ""
    String dbDriver = "oracle.jdbc.OracleDriver"

    // Constructor that sets up the project reference
    DbaExtension(Project project) {
        this.project = project
    }

}
