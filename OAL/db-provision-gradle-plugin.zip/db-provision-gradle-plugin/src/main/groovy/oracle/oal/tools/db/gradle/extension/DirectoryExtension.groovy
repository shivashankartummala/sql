package oracle.oal.tools.db.gradle.extension

import org.gradle.api.Project
import org.gradle.api.Task

// Container for all the necessary information about a database directory
class DirectoryExtension {

    // Pointer to the gradle project, used to process the tasks added for a project
    Project project

    // System Properties
    String name = ""
    String path = ""

    // Constructor that sets up the project reference
    DirectoryExtension(Project project) {
        this.project = project
    }

}
