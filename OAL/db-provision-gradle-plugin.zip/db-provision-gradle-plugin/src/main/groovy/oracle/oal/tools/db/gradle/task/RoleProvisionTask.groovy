package oracle.oal.tools.db.gradle.task

import org.gradle.api.DefaultTask
import org.gradle.api.tasks.TaskAction

// Class to provision database roles
class RoleProvisionTask extends DefaultTask {

    @TaskAction
    def roleProvision() {

        project.logger.quiet "\n---------------------------------------------------"
        project.logger.quiet "Provisioning role "+details.roleName+"..."
        project.logger.quiet "Connecting to database..."
        def dba = project.dba
        def sql = groovy.sql.Sql.newInstance(dba.dbUrl, dba.dbaUser, dba.dbaPass, dba.dbDriver)
        try {
            project.logger.quiet "Creating role..."
            try {
                def stmt = "create role "+details.roleName
                project.logger.info "SQL: "+stmt
                sql.execute(stmt)
            }
            catch (Exception e) {
                if (e instanceof java.sql.SQLException && e.getErrorCode() == 1921) {
                    project.logger.quiet "Ignore role exists error ORA-01921."
                } else {
                    throw e
                }
            }
            details.grantList.each { grant ->
                def stmt = "grant "+grant+" to "+details.roleName
                project.logger.info "SQL: "+stmt
                sql.execute(stmt)
            }
            project.logger.quiet "Provisioned role "+details.roleName
            project.logger.quiet "---------------------------------------------------\n"
        }
        finally {
            sql.close()
        }

    }

}
