package oracle.oal.tools.db.gradle.task

import org.gradle.api.DefaultTask
import org.gradle.api.tasks.TaskAction

// Class to provision database directories
class DirectoryProvisionTask extends DefaultTask {

    @TaskAction
    def provisionDirectory() {

        project.logger.quiet "\n---------------------------------------------------"
        project.logger.quiet "Creating database directory..."
        def dba = project.dba
        def sql = groovy.sql.Sql.newInstance(dba.dbUrl, dba.dbaUser, dba.dbaPass, dba.dbDriver)
        try {
            def stmt = "create or replace directory "+details.name+" as '"+details.path+"'"
            project.logger.info "SQL: "+stmt
            sql.execute(stmt)
            stmt = "grant all on directory "+details.name+" to public"
            project.logger.info "SQL: "+stmt
            sql.execute(stmt)
            project.logger.quiet "Created database directory."
            project.logger.quiet "---------------------------------------------------\n"
        }
        finally {
            sql.close()
        }

    }
}
