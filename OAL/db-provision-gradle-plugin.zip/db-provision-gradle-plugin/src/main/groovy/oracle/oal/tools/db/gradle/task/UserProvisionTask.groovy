package oracle.oal.tools.db.gradle.task

import org.gradle.api.DefaultTask
import org.gradle.api.tasks.TaskAction

// Class to provision database users
class UserProvisionTask extends DefaultTask {

    @TaskAction
    def userProvision() {

        project.logger.quiet "\n---------------------------------------------------"
        project.logger.quiet "Provisioning user "+details.userName+"..."
        project.logger.quiet "Connecting to database..."
        def dba = project.dba
        def sql = groovy.sql.Sql.newInstance(dba.dbUrl, dba.dbaUser, dba.dbaPass, dba.dbDriver)
        try {
            project.logger.quiet "Creating user..."
            try {
                def stmt = "create USER "+details.userName + " IDENTIFIED BY " + details.userPassword
				if(details.userTableSpace){
				stmt +=" DEFAULT TABLESPACE " + details.userTableSpace + " QUOTA 5M on " + details.userTableSpace
				}
                project.logger.info "SQL: "+stmt
                sql.execute(stmt)
            }
            catch (Exception e) {
                if (e instanceof java.sql.SQLException && e.getErrorCode() == 1920) {
                    project.logger.quiet "Ignore user exists error ORA-01920."
                } else {
                    throw e
                }
            }
            details.grantList.each { grant ->
                def stmt = "grant "+grant+" to "+details.userName
                project.logger.info "SQL: "+stmt
                sql.execute(stmt)
            }           
			if(details.nonDefaultRoleList){
			    project.logger.quiet "setting non defualt roles for the user..."
				// def stmt0 = "alter user " + details.userName + " default roles NONE "
				// sql.execute(stmt0)
				 
				details.nonDefaultRoleList.each { role ->
                def stmt = "alter user " + details.userName + " default roles ALL EXCEPT " +role
                project.logger.info "SQL: "+stmt
                sql.execute(stmt)
            } 
			   
               			
           			
			}
			
			 project.logger.quiet "Provisioned user "+details.userName
            project.logger.quiet "---------------------------------------------------\n"
			
			
        }
        finally {
            sql.close()
        }

    }

}
