package oracle.oal.tools.db.gradle

import org.gradle.api.artifacts.Configuration
import org.gradle.api.file.FileCollection
import org.gradle.api.logging.StandardOutputListener
import org.gradle.api.Project
import org.gradle.api.Plugin
import org.gradle.api.Task
import org.gradle.api.tasks.TaskCollection
import org.gradle.api.artifacts.dsl.DependencyHandler
import org.gradle.internal.reflect.Instantiator

import oracle.oal.tools.db.gradle.extension.*
import oracle.oal.tools.db.gradle.task.*

// Main Plugin class that controls the application of the plugin to the build script
class DbProvisionPlugin implements Plugin<Project> {

    // This gets called when a build script includes the apply plugin call
    void apply(Project project) {

        // Creates the top level extension property for the DB Provisioning Plugin
        project.extensions.create("dbProvision", DbProvisionExtension, project)

        // Creates the action tasks
        project.task("provision",   group: "Provisioning", description: "Provisions database schemas")
        
        // Automatically registers oracle jdbc driver if a file is given
        project.rootProject.allprojects.each { prj ->
            prj.buildscript.configurations.classpath.each { file ->
                if (file.name.contains("ojdbc")) {
                    try {
                        URLClassLoader loader = GroovyObject.class.classLoader
                        loader.addURL(file.toURI().toURL())
                        java.sql.DriverManager.registerDriver(loader.loadClass("oracle.jdbc.OracleDriver").newInstance())
                    }
                    catch (Exception e) {
                        project.logger.lifecycle "Skipped error registering SQL driver for "+file.name
                    }
                }
            }
        }
    }
}
