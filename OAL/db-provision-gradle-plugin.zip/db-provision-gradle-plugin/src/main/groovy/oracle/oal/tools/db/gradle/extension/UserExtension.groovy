package oracle.oal.tools.db.gradle.extension

import org.gradle.api.Project
import org.gradle.api.Task

// Container for all the necessary information about a user
class UserExtension {

    // Pointer to the gradle project, used to process the tasks added for a project
    Project project

    // User Properties
    String userName = ""
	String userPassword = ""
	String userTableSpace = ""	
    List grantList = []
	List nonDefaultRoleList = []
	
	

    // Constructor that sets up the project reference
    UserExtension(Project project) {
        this.project = project
    }

}
