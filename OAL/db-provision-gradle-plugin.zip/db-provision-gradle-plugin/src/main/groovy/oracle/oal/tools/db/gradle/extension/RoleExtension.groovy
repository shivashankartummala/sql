package oracle.oal.tools.db.gradle.extension

import org.gradle.api.Project
import org.gradle.api.Task

// Container for all the necessary information about a role
class RoleExtension {

    // Pointer to the gradle project, used to process the tasks added for a project
    Project project

    // Role Properties
    String roleName = ""
    List grantList = []

    // Constructor that sets up the project reference
    RoleExtension(Project project) {
        this.project = project
    }

}
