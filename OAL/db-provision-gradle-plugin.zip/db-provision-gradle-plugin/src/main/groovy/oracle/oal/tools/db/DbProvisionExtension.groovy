package oracle.oal.tools.db.gradle

import org.gradle.api.Project
import org.gradle.api.Task

import oracle.oal.tools.db.gradle.extension.*
import oracle.oal.tools.db.gradle.task.*

// Container for all the necessary information about a schema to provision
class DbProvisionExtension {

    // Pointer to the gradle project, used to process the tasks added for a project
    Project project

    // Constructor from the plugin apply method that sets up the project reference
    DbProvisionExtension(Project project) {
        this.project = project
    }

    // Method allowing the build script to define the system connection with a closure
    void dba(Closure closure) {
        // Read the dba properties and store in the project
        DbaExtension dbaDetails = new DbaExtension(project)
        project.configure(dbaDetails, closure)
        // Add the DBA properties to the project so they are accessible from all the tasks
        project.ext.dba = dbaDetails
    }
    
    // Method allowing the build script to define database directories with a closure
    void directory(Closure closure) {
        DirectoryExtension taskDetails = new DirectoryExtension(project)
        project.configure(taskDetails, closure)
        // Create a task for provisioning the directory
        Task t = project.task("provisionDirectory_"+taskDetails.name,  type: DirectoryProvisionTask,  group: 'Provision')
        // Add the directory extension details to the task
        t.ext.details = taskDetails
        // Add provisionDirectory task dependency from the provision task
        project.provision.dependsOn(t)
    }

    // Method allowing the build script to define the roles to provision with a closure
    void role(Closure closure) {
        // Read the role properties
        RoleExtension roleDetails = new RoleExtension(project)
        project.configure(roleDetails, closure)
        // Create a task for provisioning the role
        Task t = project.task("provisionRole_"+roleDetails.roleName,  type: RoleProvisionTask,  group: 'Provision')
        // Add the role extension details to the task
        t.ext.details = roleDetails
        // Add provisionRole task dependency from the provision task
        project.provision.dependsOn(t)
    }
	
	// Method allowing the build script to define the user to provision with a closure
    void user(Closure closure) {
        // Read the role properties
        UserExtension userDetails = new UserExtension(project)
        project.configure(userDetails, closure)
        // Create a task for provisioning the user
        Task t = project.task("provisionUser_"+userDetails.userName,  type: UserProvisionTask,  group: 'Provision')
        // Add the user extension details to the task
        t.ext.details = userDetails
        // Add provisionUser task dependency from the provision task
        project.provision.dependsOn(t)
    }

}
