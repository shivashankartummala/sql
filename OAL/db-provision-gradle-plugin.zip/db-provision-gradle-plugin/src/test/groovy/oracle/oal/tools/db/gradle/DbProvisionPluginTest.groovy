package oracle.oal.tools.db.gradle

import oracle.oal.tools.db.gradle.task.*

import org.junit.Test
import org.gradle.testfixtures.ProjectBuilder
import org.gradle.api.Project

import static org.junit.Assert.*

class DbProvisionPluginTest {
    @Test
    public void pluginAddsTasksToProject() {
        Project project = ProjectBuilder.builder().build()
        project.pluginManager.apply 'com.oracle.oal.db'

        def db = project.extensions.dbProvision
        project.configure(db,{
            role {
                roleName = 'TEST'
                grantList = ["GRANT1","GRANT2"]
            }
            directory {
                name = 'TEST'
            }
			user {
			userName = "TEST"
			userPassword = "password1234"
			grantList = ["CONNECT", "RESOURCE", "CREATE SESSION" ,"DBA" ]
			}
        })

        assertTrue(project.tasks.provisionRole_TEST instanceof RoleProvisionTask)
        assertTrue(project.tasks.provisionDirectory_TEST instanceof DirectoryProvisionTask)
		assertTrue(project.tasks.provisionUser_TEST instanceof UserProvisionTask)
    }
}
